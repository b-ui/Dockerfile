from mod_btcoin.task import scheduler

scheduler.start()
