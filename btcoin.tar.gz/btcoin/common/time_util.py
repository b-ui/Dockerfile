import pytz

TZ_SH = pytz.timezone("Asia/Shanghai")